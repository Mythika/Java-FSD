package ThirdAssignment;
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    LinkedList() {
        this.head = null;
    }
    void append(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }

        Node last = head;
        while (last.next != null) {
            last = last.next;
        }

        last.next = newNode;
    }
 
    void deleteKey(int key) {
        Node current = head;
        Node prev = null;

        
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }
 
        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }
 
        prev.next = current.next;
    }
 
    void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class FirstOccuranceDelete {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

   
        linkedList.append(1);
        linkedList.append(2);
        linkedList.append(3);
        linkedList.append(4);
        linkedList.append(5);

        System.out.println("Original Linked List:");
        linkedList.display();
 
        int keyToDelete = 4;
        linkedList.deleteKey(keyToDelete);

        System.out.println("Linked List after deleting key " + keyToDelete + ":");
        linkedList.display();
    }
}

