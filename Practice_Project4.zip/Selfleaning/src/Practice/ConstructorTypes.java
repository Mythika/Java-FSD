package Practice;
class B{
	B() {
		System.out.println("Default Constructor");
	}
	B(String s){
		System.out.println(s);
	}
}
public class ConstructorTypes {

	public static void main(String[] args) {
		B ob=new B();
		B ob1 = new B("parameterized constructor ");

	}

}
