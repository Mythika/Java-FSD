package Practice;
import java.util.*;

public class MapImplementation {

	public static void main(String[] args) {
	    System.out.println("HashMap");
		HashMap<Integer,String> mp =new HashMap<Integer,String>();
		mp.put(1,"Chennai");
		mp.put(2,"Bengaluru");
		mp.put(3,"Hydrabad");
		mp.put(4,"Pune");
		for(Map.Entry x : mp.entrySet()) {
		System.out.println(x.getKey()+" "+x.getValue());
		}
		
		System.out.println("\nLinked HashMap");
		LinkedHashMap<Integer,String> lm = new LinkedHashMap<Integer,String>();
		lm.put(1,"Chennai");
		lm.put(2,"Bengaluru");
		lm.put(3,"Hydrabad");
		lm.put(4,"Pune");
		for(Map.Entry y : lm.entrySet()) {
			System.out.println(y.getKey()+" "+y.getValue());
			}		
		
		System.out.println("\nTree Map");
		TreeMap<Integer,String> tm = new TreeMap<Integer,String>();
		tm.put(1,"Chennai");
		tm.put(2,"Bengaluru");
		tm.put(3,"Hydrabad");
		tm.put(4,"Pune");
		for(Map.Entry z : tm.entrySet()) {
			System.out.println(z.getKey()+" "+z.getValue());
			}		

	}

}
