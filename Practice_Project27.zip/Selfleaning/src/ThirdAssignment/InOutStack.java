package ThirdAssignment;
class CustomStack {
    private static final int MAX_SIZE = 100;
    private int[] array;
    private int top;

    public CustomStack() {
        array = new int[MAX_SIZE];
        top = -1;
    }

    public void push(int element) {
        if (top < MAX_SIZE - 1) {
            array[++top] = element;
            System.out.println("Pushed " + element + " onto the stack.");
        } else {
            System.out.println("Stack overflow. Cannot push " + element + " onto the stack.");
        }
    }

    public void pop() {
        if (top >= 0) {
            int poppedElement = array[top--];
            System.out.println("Popped " + poppedElement + " from the stack.");
        } else {
            System.out.println("Stack is empty. Cannot pop an element.");
        }
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void displayStack() {
        if (isEmpty()) {
            System.out.println("Stack is empty.");
        } else {
            System.out.print("Elements in the stack: ");
            for (int i = 0; i <= top; i++) {
                System.out.print(array[i] + " ");
            }
            System.out.println();
        }
    }
}

public class InOutStack {

    public static void main(String[] args) {
        CustomStack customStack = new CustomStack();

        customStack.push(5);
        customStack.push(10);
        customStack.push(15);

        customStack.displayStack();

        customStack.pop();
        customStack.pop();

        customStack.displayStack();
    }
}
