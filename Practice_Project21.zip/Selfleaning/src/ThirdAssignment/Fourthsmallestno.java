package ThirdAssignment;

import java.util.Arrays;

public class Fourthsmallestno {

    public static void main(String[] args) {
        int[] unsortedList = {12, 8, 7, 5, 2, 4, 6, 9, 3, 11};
        int fourthSmallest = findFourthSmallestElement(unsortedList);

        System.out.println("Unsorted List: " + Arrays.toString(unsortedList));
        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }

    static int findFourthSmallestElement(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List has less than four elements.");
            return -1; 
        }

        Arrays.sort(arr);

        return arr[3]; 
    }
}
