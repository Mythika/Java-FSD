package Methodcall;

public class Methodcalling {
    int value=150;

	public int divide(int value) {
		value =value*10/100;
		System.out.println(value);
		return(value);
	}

	public static void main(String args[]) {
		Methodcalling f = new Methodcalling();
		System.out.println("Before operation value of data is "+f.value);
		f.divide(100);
		System.out.println("After operation value of data is "+f.value);
		}
	}

