package Practice;

import java.util.*;

public class Collections {

	public static void main(String[] args) {
		System.out.println("1) Array list :");
		ArrayList<String> arr = new ArrayList<String>();
		arr.add("Chennai");
		arr.add("Coimbatore");
		arr.add("Salem");
		arr.add("Trichy");
		System.out.println(arr);
		
		System.out.println("\n2) Linked list :");
		LinkedList<String> lrr = new LinkedList<String>();
        lrr.add("Tamilnadu");
        lrr.add("Kerala");
        lrr.add("UP");
        lrr.add("MP");
		System.out.println(lrr);
		
		System.out.println("\n3) Hashset :");
	    HashSet<String> hset = new HashSet<String>();
	    hset.add("Tamil");
	    hset.add("English");
	    hset.add("Telugu");
	    hset.add("Hindi");
		System.out.println(hset);

		System.out.println("\n4) LinkedHashSet :");
	    LinkedHashSet<String> lhset = new LinkedHashSet<String>();
	    lhset.add("Biology");
	    lhset.add("Maths");
	    lhset.add("Science");
	    lhset.add("History");
		System.out.println(lhset);
		
		System.out.println("\n5) Vector :");
		Vector<String> vec =new Vector<String>();
		vec.addElement("15");
		vec.addElement("69");
		vec.addElement("35");
		vec.addElement("90");
		System.out.println(vec);


	}

}
