package ThirdAssignment;

class Node1 {
    int data;
    Node1 next;

    Node1(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node1 head;

    CircularLinkedList() {
        this.head = null;
    }

    void insertSorted(int data) {
        Node1 newNode = new Node1(data);
 
        if (head == null) {
            head = newNode;
            newNode.next = head;
            return;
        }

         if (data < head.data) {
            newNode.next = head;
            head = newNode;
            return;
        }

         Node1 current = head;
        while (current.next != head && current.next.data < data) {
            current = current.next;
        }

         newNode.next = current.next;
        current.next = newNode;
    }

     void display() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        Node1 current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class NewInsertCirLL {
    public static void main(String[] args) {
        CircularLinkedList circularList = new CircularLinkedList();

         circularList.insertSorted(2);
        circularList.insertSorted(4);
        circularList.insertSorted(6);
        circularList.insertSorted(8);

        System.out.println("Original Sorted Circular Linked List:");
        circularList.display();

         int elementToInsert = 5;
        circularList.insertSorted(elementToInsert);

        System.out.println("Sorted Circular Linked List after inserting " + elementToInsert + ":");
        circularList.display();
    }
}
