package ThirdAssignment;

import java.util.LinkedList;
import java.util.Queue;

public class QueueCode {

    public static void main(String[] args) {
         Queue<Integer> queue = new LinkedList<>();

        enqueueElement(queue, 5);
        enqueueElement(queue, 10);
        enqueueElement(queue, 15);

         displayQueue(queue);

         dequeueElement(queue);
        dequeueElement(queue);

         displayQueue(queue);
    }

     static void enqueueElement(Queue<Integer> queue, int element) {
        queue.offer(element);
        System.out.println("Enqueued " + element + " into the queue.");
    }

     static void dequeueElement(Queue<Integer> queue) {
        if (!queue.isEmpty()) {
            int dequeuedElement = queue.poll();
            System.out.println("Dequeued " + dequeuedElement + " from the queue.");
        } else {
            System.out.println("Queue is empty. Cannot dequeue an element.");
        }
    }

     static void displayQueue(Queue<Integer> queue) {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty.");
        } else {
            System.out.println("Elements in the queue: " + queue);
        }
    }
}

